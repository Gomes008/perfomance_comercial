@extends('layouts.main')

@section('title', 'Comercial')

@section('content')

<div class="bg-white rounded shadow mb-5 select-container">
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <center>
        <h1>Avaliação Gomes Silva Banze </h1>
        <p>Desenvolvimento de Funcionalidade <a href="/inicio">"Perfomance Comercial"</a>  (Comescial -> Perfomance Comercial)</p>
    </center>
    
</div>
@endsection

