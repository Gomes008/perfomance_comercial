

<?php $__currentLoopData = $consultores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="table-responsive">    
    <table class="table ls-table" id="tabela1">
        <thead>
            <tr>
                <th colspan="5"><?php echo e($consultor['nome']); ?></th>
            </tr>
        </thead>
        <tbody>
            <tr id="tr-subtitle">
                <td>Período</td>
                <td>Receita Líquida</td>
                <td>Custo Fixo</td>
                <td>Comissäo</td>
                <td>Lucro</td>
            </tr>
            <?php $__currentLoopData = $consultor['periodos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($consultor['usuario'] == $per['usuario']): ?>
            <tr>
                <td><?php echo e($per['periodo']); ?></td>
                <td><?php echo e(number_format($per['liquido'], 2)); ?> </td>
                <td><?php echo e(number_format($per['salario'], 2)); ?></td>
                <td><?php echo e(number_format($per['comissao'], 2)); ?></td>
                <td>
                    <div class = "<?php echo e($per['lucro'] >= 0 ? '' : 'red-class'); ?>">
                    <?php echo e(number_format($per['lucro'], 2)); ?></td>
                    </div>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr id="tr-total">
                <td>TOTAL</td>
                <td><?php echo e(number_format($consultor['liquidoPeriodo'], 2)); ?> </td>
                <td><?php echo e(number_format($consultor['salarioPeriodo'], 2)); ?></td>
                <td><?php echo e(number_format($consultor['comissaoPeriodo'], 2)); ?></td>
                <td>
                   <div class = "<?php echo e($consultor['lucroPeriodo'] >= 0 ? 'blue-class' : 'red-class'); ?>">
                    <?php echo e(number_format($consultor['lucroPeriodo'], 2)); ?>

                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\projetos\laravel\comercial\resources\views/consultores/relatorio.blade.php ENDPATH**/ ?>