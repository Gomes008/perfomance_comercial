

<div id="pizzaConsultor" style="min-width: 310px;  margin: 0 auto"></div>

<script type="text/javascript">

  Highcharts.chart('pizzaConsultor', {
      chart: {
          plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          type: 'pie'
      },
      title: {
          text: 'Porcentagem do valor líquido referente aos consultores e período selecionado'
      },
      tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      plotOptions: {
          pie: {
              allowPointSelect: true,
              cursor: 'pointer',
              dataLabels: {
                  enabled: true,
                  format: '<b>{point.name}</b>: {point.percentage:.1f} %'
              }
          }
      },
      series: [{
          name: 'Brands',
          colorByPoint: true,
          data: [
            <?php $__currentLoopData = $consultores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($consultor['liquido'] != 0): ?>
            {
              name:  "<?php echo e($consultor['nome']); ?>",
              y: <?php echo e($consultor['liquido']); ?> / <?php echo e($total); ?>

          }, 
          <?php endif; ?> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          ]
      }]
  });
</script><?php /**PATH D:\projetos\laravel\comercial\resources\views/consultores/pizza.blade.php ENDPATH**/ ?>