<?php $__env->startSection('title', 'Comercial'); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-white rounded shadow mb-5 select-container">
    <!-- Bordered tabs-->
    <ul id="myTab1" role="tablist" class="nav nav-tabs nav-pills with-arrow flex-column flex-sm-row text-center">
        <li class="nav-item flex-sm-fill">
            <a id="consultor-tab" data-toggle="tab" href="#consultor" role="tab" aria-controls="consultor" aria-selected="true" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0 border active">Por Cosultor</a>
        </li>
        <li class="nav-item flex-sm-fill">
            <a id="cliente-tab" data-toggle="tab" href="#cliente" role="tab" aria-controls="cliente" aria-selected="false" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0 border">Por Cliente</a>
        </li>
    </ul>
    <div id="select-area">
        &nbsp;&nbsp;
        <select name="mes1" id="mes1">
        <option value="1">Jan</option>
            <option value="2">Fev</option>
            <option value="3">Mar</option>
            <option value="4">Abr</option>
            <option value="5">Mai</option>
            <option value="6">Jun</option>
            <option value="7">Jul</option>
            <option value="8">Ago</option>
            <option value="9">Set</option>
            <option value="10">Out</option>
            <option value="11">Nov</option>
            <option value="12">Dez</option>
        </select>
        <select name="ano1" id="ano1">
            <?php for($i=2007; $i<=2012; $i++): ?>
            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
            <?php endfor; ?>
        </select>
        &nbsp;a&nbsp;
        <select name="mes2" id="mes2">
            <option value="1">Jan</option>
            <option selected value="2">Fev</option>
            <option value="3">Mar</option>
            <option value="4">Abr</option>
            <option value="5">Mai</option>
            <option value="6">Jun</option>
            <option value="7">Jul</option>
            <option value="8">Ago</option>
            <option value="9">Set</option>
            <option value="10">Out</option>
            <option value="11">Nov</option>
            <option value="12">Dez</option>
        </select>
        <select name="ano2" id="ano2">
            <?php for($i=2007; $i<=2012; $i++): ?>
            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
            <?php endfor; ?>
        </select>
    </div>
    <div id="myTab1Content" class="tab-content">
        <div id="consultor" role="tabpanel" aria-labelledby="consultor-tab" class="tab-pane fade show active">
            <div class="row">

                <div id="select-container-consultant" class="col-lg-10">
                    <div class="dual-list-box-inner">
                        <form id="form_consultant" class="wizard-big">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            <select class="form-control dual_select" id="consultant[]" name="consultant[]" multiple>
                                <?php $__currentLoopData = $consultores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($consultor->co_usuario); ?>"><?php echo e($consultor->no_usuario); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </form>
                    </div>
                </div>
            
                <div id="btn-report-consultant" class="col-lg-2">
                    <div class="nav flex-column nav-pills nav-pills-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                        <a class="nav-link mb-3 p-3 shadow" onclick="consultorRelatorio();" id="report_consultant" data-toggle="pill" href="#" role="tab" aria-controls="v-pills-home" aria-selected="true">
                        <ion-icon name="document-text-outline"></ion-icon>
                        <span class="font-weight-bold small text-uppercase">Relaório</span></a>

                        <a class="nav-link mb-3 p-3 shadow" onclick="consultorGrafico();" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">
                        <ion-icon name="bar-chart-outline"></ion-icon>
                        <span class="font-weight-bold small text-uppercase">Gráfico</span></a>

                        <a class="nav-link mb-3 p-3 shadow" onclick="consultorPizza();" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
                        <ion-icon name="bowling-ball-outline"></ion-icon>
                        <span class="font-weight-bold small text-uppercase">Pizza</span></a>
                    </div>
                </div>
            </div>
            <div id="info-container-consultant" class="col-lg-12">
                          
            </div>
        </div>

        <div id="cliente" role="tabpanel" aria-labelledby="cliente-tab" class="tab-pane fade">
            <div class="row ">

                <div id="select-container-client" class="col-lg-10">
                    <div class="dual-list-box-inner">
                        <form id="form_client" name="form_client" class="wizard-big">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                            <select class="form-control dual_select" name="client[]" id="client" multiple>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cliente->co_cliente); ?>"><?php echo e($cliente->no_fantasia); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </form>
                    </div>
                </div>

                <div id="btn-report-client" class="col-lg-2">
                    <div class="nav flex-column nav-pills nav-pills-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                        <a class="nav-link mb-3 p-3 shadow active" onclick="clienteRelatorio();" id="consultant-report-tab" data-toggle="pill" href="#consultant-report" role="tab" aria-controls="consultant-report" aria-selected="true">
                        <ion-icon name="document-text-outline"></ion-icon>
                        <span class="font-weight-bold small text-uppercase">Relaório</span></a>

                        <a class="nav-link mb-3 p-3 shadow" onclick="clienteGrafico();" id="consultant-chart-tab" data-toggle="pill" href="#consultant-chart" role="tab" aria-controls="consultant-chart" aria-selected="false">
                        <ion-icon name="bar-chart-outline"></ion-icon>
                        <span class="font-weight-bold small text-uppercase">Gráfico</span></a>

                        <a class="nav-link mb-3 p-3 shadow" onclick="clientePizza();" id="consultant-pizza-tab" data-toggle="pill" href="#consultant-pizza" role="tab" aria-controls="consultant-pizza" aria-selected="false">
                        <ion-icon name="bowling-ball-outline"></ion-icon>
                        <span class="font-weight-bold small text-uppercase">Pizza</span></a>
                    </div>
                </div>
            </div>
            <div id="info-container-client" class="col-lg-12">
                         
            </div>
        
        </div>
    <!-- End bordered tabs -->
    </div>
    
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projetos\laravel\comercial\resources\views/welcome.blade.php ENDPATH**/ ?>