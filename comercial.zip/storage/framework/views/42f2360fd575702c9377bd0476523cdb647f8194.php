

<div class="table-responsive">    
    <table class="table ls-table" id="tabela1">
         <thead>
             
         </thead>
         <tbody>
             <tr id="tr-subtitle">
                 <td>Período</td>
                 <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <td><?php echo e($cliente['cliente']); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
             </tr>
             <?php $__currentLoopData = $tempo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
                <td><?php echo e((new DateTime($temp->format("Y-m")))->format('F Y')); ?></td>

                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $cliente['periodos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cliente['clienteid'] == $per['clienteid'] && $per['peri']->format("Y-m") == $temp->format("Y-m")): ?>
                 <td> 
                 <div class = "<?php echo e($cliente['maximo'] == $per['liquido'] ? 'blue-class' : ''); ?>"> 
                     <?php echo e(number_format($per['liquido'], 2)); ?> </td>  
                </div>
                 <?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
             </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
             <tr id="tr-total">
                <td>Total</td>
                
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <td><?php echo e(number_format($cliente['totalp'], 2)); ?> </td>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tr>
             
         </tbody>
    </table>
</div> 

<?php /**PATH D:\projetos\laravel\comercial\resources\views/clientes/relatorio.blade.php ENDPATH**/ ?>