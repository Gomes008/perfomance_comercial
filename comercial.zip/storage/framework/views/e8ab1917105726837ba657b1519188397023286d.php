
<div id="pizzaCliente" style="min-width: 310px;  margin: 0 auto"></div>

<script type="text/javascript">
  Highcharts.chart('pizzaCliente', {
      chart: {
          plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          type: 'pie'
      },
      title: {
          text: 'Porcentagem do valor líquido referente aos clientes e período selecionado'
      },
      tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      plotOptions: {
          pie: {
              allowPointSelect: true,
              cursor: 'pointer',
              dataLabels: {
                  enabled: true,
                  format: '<b>{point.name}</b>: {point.percentage:.1f} %'
              }
          }
      },
      series: [{
          name: 'Brands',
          colorByPoint: true,
          data: [
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($cliente['liquido'] != 0): ?>
            {
              name:  "<?php echo e($cliente['cliente']); ?>",
              y: <?php echo e($cliente['liquido']); ?> / <?php echo e($total); ?>

          }, 
          <?php endif; ?> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          ]
      }]
  });
</script><?php /**PATH D:\projetos\laravel\comercial\resources\views/clientes/pizza.blade.php ENDPATH**/ ?>